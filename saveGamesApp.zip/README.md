# saveGamesApp
### Diclaimer: *There aren't any plans to actually deploy this, this is a personal project for learning purposes only*
- Built on Node.js with Express.js
- Used MongoDB free tier for testing purposes
- Deployed on Heroku for testing purposes only
## About the functionalities of the app:
- Anyone can go into the website and download a savegame file already uploaded without registering;
- If you have a savegame in your local machine you can upload it to the website after registering an user;
- The savegame is composed by a title, a quick description, a URL for where the save is located (could use in loco upload, depending on where the app would be deployed, or any other means of uploading file, for now it is just a placeholder for any functionalities that may come with time or in a potential release)
